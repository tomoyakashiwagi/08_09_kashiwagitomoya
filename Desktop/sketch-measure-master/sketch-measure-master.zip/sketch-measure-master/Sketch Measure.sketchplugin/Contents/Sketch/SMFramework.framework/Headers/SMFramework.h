//
//  SMFramework.h
//  SMFramework
//
//  Created by utom on 11/05/2017.
//  Copyright © 2017 UTOMBOX. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for SMFramework.
FOUNDATION_EXPORT double SMFrameworkVersionNumber;

//! Project version string for SMFramework.
FOUNDATION_EXPORT const unsigned char SMFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SMFramework/PublicHeader.h>


